#include <stdlib.h>
#include <stdio.h>

#include <SQLAPI.h>

int main()
{
    SAConnection con;
    con.setOption("UseAPI") = "DB-Lib";

    try
    {
       con.Connect("BEDLAM-M\\SQLEXP2008EN@pubs", "", "", SA_SQLServer_Client);
       SACommand cmd(&con, "select user");
       cmd.Execute();
       if( cmd.FetchNext() )
            printf("USER: %s", cmd[1].asString().GetMultiByteChars());
    }
    catch(SAException& x)
    {
        printf("ERROR %d: %s\n",
			x.ErrNativeCode(), x.ErrText().GetMultiByteChars());

    }

    return 0;
}
